OntoGuard public Decision Authorization evidence
================================================
Disclosure class: PUBLIC_SAFE
Governance pack line: v1.2.0
Runtime line (separate): Headless Decision Authorization Runtime 1.0.19

This ZIP contains only buyer-facing public artifacts.
It does not contain full-audit JSON, seam packs, model identifiers,
thresholds, source code, or customer-route material.

Detailed evidence is available through technical diligence:
mark.starobinsky@ontoguard.ai
