OntoGuard public Decision Authorization evidence
================================================
Disclosure class: PUBLIC_SAFE
Governance pack line: v1.2.0
Runtime line (separate): Headless Decision Authorization Runtime 1.2.21
Platform: OntoGuard Decision Authorization Platform (full operating environment)
AgenTrust: TRACE integration listed at the Verified tier (published integration behavior against released packages; not hardware attestation, L5, or product certification)

The September 17 financial one-pager summarizes a controlled evidence event. It does not imply that event was executed under Runtime 1.2.21 unless separately stated.

This ZIP contains only buyer-facing public artifacts.
Detailed evidence is available through technical diligence:
mark.starobinsky@ontoguard.ai
