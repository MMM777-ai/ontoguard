# Replacement Notes - v6

Use this release in place of the prior public Boundary Proof Kit. Existing public filenames are preserved.

## Why replaced

The prior package accurately represented the current boundary/seam, R7, continuity and custody story, but did not fully expose the earlier Goal 3 code-now acceptance surfaces. v6 adds the complete 15/15 acceptance matrix and current-run metrics without changing the controlled-vs-production claim boundary.

## Release truth

- Goal 3 code-now: COMPLETE 15/15
- Sections 46-54: implemented
- Current event: ESCALATE / release withheld / NO-BIND / event-level shadow proof
- Controlled Full Seam: PASS 22/22 / L4_ROUTE_ENFORCED / bounded controlled route only
- Production L5: not asserted
- Single harness: 7373 / 0 / 0
- Batch harness: 2221 / 0 / 0
- Generated: 2026-08-23T20:53:06Z
