# Replacement Notes - v5

This replacement supersedes the prior public kit derived from older trace/batch identifiers.

Changed in this release:

- source moved to `83b5bdd9-7b5f-40c1-9e34-75573e0aac54` and `corr_batch_eb331c8dd974`;
- Goal 3 code-now completion explicitly represented as 15/15;
- R7 Intent Horizon added as a decision-driving pre-decision input;
- Governing Basis Continuity and Lawful Continuation added;
- Retrieval Source Authority and Tool Capability Authority added;
- Evidence Custody and External Runtime-State Attestation status added;
- Consequence Custody added;
- current-event evidence separated from the 22/22 controlled Full Seam L4 fixture;
- Semantic Curvature / Governance Spectrum expose honest insufficient-history states;
- learning language is review-gated rather than closed-loop;
- production L5 remains customer-topology dependent.

Existing website filenames are retained.
