# OntoGuard v4 Public Proof Kit Replacement Notes

Generated: 2026-07-11T19:11:01Z

## Why these replacements were created

These files replace every asset in the prior public kit while retaining every filename and package naming convention. The content now reflects the latest code, final source artifacts, and verification results.

## Changes reflected

- Canonical eight-stage `governed_event_lifecycle` is present in the DAP and shown on page one.
- Controlled-batch visible case Decision API mirrors match the authoritative case outcomes.
- Stale legacy ALLOW/BLOCK input mirrors are quarantined in full-audit forensics only.
- Benchmark corpus identity is consistently marked as an internal synthetic 2026 OntoGuard reference.
- Historical and rejected benchmark scope metadata is excluded from buyer-visible authority.
- Decision API parity is separated from underlying projection-score preference divergence.
- Single and batch strict-six packages passed the attached post-harness suites with zero warnings and zero failures.
- Public proof continues to state the event-level/no-bind boundary and does not assert production L5 enforcement.

## Replacement policy

- Keep every filename exactly the same.
- Upload the contents to the same website asset locations.
- Replace, do not append to, the existing public kit files.
- Keep the inner six-file `governance.public_sanitized.zip` intact.
- Do not expose raw source strict-six packages, private ontology internals, or protected implementation details.

Use `OntoGuard_Boundary_Proof_Kit_Public_Sanitized.zip` as the logical public complete-kit download name.
