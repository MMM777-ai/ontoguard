# Replacement Notes - v8

Use v8 in place of v7 when the audience needs a substantive Boundary Proof Kit rather than a minimal teaser.

## What changed from v7

Restored buyer-safe evidence for authority, approval, evidence custody/causality counts, trust/uncertainty, benchmark context, R7 status, longitudinal-governance status, Full Seam maturity, replay, human-review closure, artifact integrity, and current acceptance.

Still withheld: proprietary formulas, weights, model/embedding fingerprints, internal hashes/IDs, raw evidence/candidate inventories, retrieval mechanics, private source/provenance topology, test-case identifiers, and local operational paths.

## Release truth

- Current representative event: ESCALATE / WITHHELD_PENDING_REVIEW / HUMAN_REVIEW / no protected effect formed.
- Primary decision cause: GOVERNING_AUTHORITY_NOT_ESTABLISHED.
- Current event maturity: event governed; production route completeness not asserted.
- Controlled Full Seam: PASS / L4_ROUTE_ENFORCED / bounded controlled route only.
- Single harness: 7479 / 6 / 0.
- Latest batch harness: 2504 / 0 / 1 and therefore not asserted as clean release acceptance.
- Production L5 / production-wide non-bypassability: not asserted.
