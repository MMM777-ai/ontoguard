# OntoGuard Full-Seam Evidence Set - Public-Safe Rich

Generated: 2026-09-09T14:48:14Z

This package is an up-to-date public technical proof of OntoGuard's bounded seam and Pre-Transition Governing Floor.

## What is preserved
The package retains the useful proof categories from the earlier Full-Seam set:
- formation standing before authorization;
- current release withholding and zero protected effect;
- valid authorization permits exactly one controlled protected commit;
- BLOCK/ESCALATE and decision-failure states produce zero commit;
- missing/malformed authorization fails closed;
- six controlled context/binding mismatch variants fail closed without publishing which private binding axes were tested;
- stale/revoked/expired/reused authorization fails closed;
- concurrent duplicate control yields exactly one commit;
- two controlled bypass categories fail closed;
- same-condition replay is equivalent;
- changed-condition replay re-enters the governed gate;
- authority, evidence, legal-semantic, trust/uncertainty, longitudinal-governance, lifecycle and acceptance context remain available.

## Why the 22 tests are grouped
The attached older package enumerated the private authorization-binding taxonomy in enough detail to create architectural inference risk. This version still reports **22/22 passed**, preserves category-level case counts and observed outcomes, but groups the exact binding axes into `CONTEXT_OR_BINDING_MISMATCH`.

## Current-event truth
- Decision = ESCALATE
- Release = WITHHELD_PENDING_REVIEW
- Downstream protected commit = NOT_COMMITTED
- Protected effect formed = false
- Human review remains pending
- Production-wide non-bypassability is not asserted

See `FULL_SEAM_REVIEW_WORKSHEET.md` for an external review path.
