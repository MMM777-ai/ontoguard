# IP Disclosure Boundary - Full-Seam Public-Safe Rich

This package preserves externally useful proof breadth without publishing the private mechanism blueprint.

## Public evidence retained
- formation Floor and STANDING / NO_STANDING / NOT_EVALUABLE semantics;
- current ESCALATE / release-withheld / no-bind outcome;
- 22/22 controlled pressure-test coverage, grouped into eight public categories;
- valid authorization, refusal, stale-state, concurrency, bypass and replay outcomes;
- authority and decision-causality posture;
- evidence/citation/applicability/authority/causality separation;
- trust/uncertainty bands and multi-role arbitration posture;
- longitudinal-governance status;
- lifecycle, strict-six readiness and acceptance posture.

## Withheld
- source code, source/module/callable identities and private paths;
- private run/route/test/receipt/evidence identifiers;
- private decision/input/movement/standing/handoff hashes;
- exact authorization-binding dimensions and exact per-test binding-axis mapping;
- private route topology;
- model, retrieval and internal-representation implementation details;
- exact metric values, role-level scores, formulas, weights, coefficients and numeric thresholds;
- raw prompts, model outputs, evidence bodies, private registry content and raw traces;
- exact private packet byte sizes and fine-grained performance fingerprints;
- secrets and private signing material.

The public package proves outcomes and invariants while materially reducing architectural fingerprinting and trade-secret inference risk.
