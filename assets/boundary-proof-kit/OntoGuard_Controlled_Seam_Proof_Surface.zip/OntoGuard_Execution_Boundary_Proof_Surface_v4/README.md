# OntoGuard Execution Boundary Proof Surface v4

This replacement keeps the existing package and file naming conventions while updating the proof surface to the latest verified code and artifacts.

It includes public-safe excerpts for:

- the canonical eight-stage governed-event lifecycle;
- single-event execution-boundary and no-bind proof;
- benchmark synthetic-corpus identity and scope hygiene;
- controlled-batch case decision-authority consistency;
- strict-six and post-harness verification.

Single source trace: `a30db149-e2c4-4001-a7f8-694ceb64af9a`.
Batch source: `corr_batch_af700a1eb8c1`.

Production L5 non-bypassability is not asserted. It requires customer route integration and production topology evidence.
