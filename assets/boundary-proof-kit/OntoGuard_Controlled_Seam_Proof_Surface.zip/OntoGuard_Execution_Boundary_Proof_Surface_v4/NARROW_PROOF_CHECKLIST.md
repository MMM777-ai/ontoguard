# Narrow Public Proof Checklist

- Canonical eight-stage governed-event lifecycle is attached.
- Authoritative Decision API outcome is preserved.
- Release authorization and refused operation are visible.
- No-bind receipt and protected-effect status are visible.
- Controlled-batch ALLOW/BLOCK/ESCALATE case mirrors match authoritative case results.
- Stale legacy case mirrors are quarantined and non-authoritative.
- Benchmark corpus is explicitly internal, synthetic, 2026, and not customer data.
- Rejected or historical scope metadata is excluded from buyer-visible benchmark identity.
- Production L5 non-bypassability is not asserted.
- No source code or protected runtime internals are disclosed.
