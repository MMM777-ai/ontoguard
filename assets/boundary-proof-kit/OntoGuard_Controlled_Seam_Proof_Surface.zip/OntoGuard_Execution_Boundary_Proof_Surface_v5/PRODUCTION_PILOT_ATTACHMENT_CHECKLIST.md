# Production Pilot Attachment Checklist

Goal 3 code-now implementation is complete. The following are customer/pilot evidence needed to assert production-wide route completeness / L5; they are not outstanding code-now defects.

1. Named customer production route inventory.
2. Real protected downstream commit endpoint.
3. OntoGuard invocation in the actual protected commit path.
4. Production authorization grant/token required for commit where applicable.
5. Missing grant/token rejection at the production endpoint.
6. Invalid, expired, revoked, reused, tenant-mismatched, route-mismatched, operation-mismatched, and decision/movement-mismatched authorization rejection as applicable.
7. Production direct/alternate bypass-attempt evidence.
8. Customer-connected same-condition replay evidence.
9. Customer-connected changed-condition replay evidence.
10. Production route pressure/fail-closed evidence.
11. Authorized reviewer identity, role, qualification, and authorization evidence.
12. Reviewer decision and downstream outcome closure.
13. Customer delegated authority and executable policy ownership.
14. Tenant, durable persistence, TLS, signing, backup/restore, access-control, retention, and deployment-operations evidence as required by the deployment.
15. Approved customer baseline and measured ROI evidence where commercial outcome claims are made.
16. Material limitations resolved, waived by authorized owner, or explicitly retained as non-production claims.
