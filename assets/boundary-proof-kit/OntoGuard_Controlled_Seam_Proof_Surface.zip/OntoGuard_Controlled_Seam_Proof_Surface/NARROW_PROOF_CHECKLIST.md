# Narrow Proof Checklist

This checklist intentionally excludes broad platform positioning, ROI, marketing claims, and full-stack assertions.

| # | Proof item | Controlled proof status | Public-safe evidence pointer | Reviewer question |
|---:|---|---|---|---|
| 1 | Attempted movement | Present | `controlled_runtime_seam_summary.public_sanitized.json` → `/release_attempt/attempted_movement` | Does the artifact show what tried to move? |
| 2 | Gate invocation | Present | `/execution_boundary/control_point`, `/execution_boundary/gate_mode`, `/execution_boundary/gate_invoked_before_release` | Was the gate invoked before release? |
| 3 | Failed condition | Present | `/execution_boundary/failed_conditions` | Does it show why autonomous release failed? |
| 4 | Refused operation | Present | `/execution_boundary/refused_operation` | Is the refused operation explicit? |
| 5 | No authorization token issued | Present | `/execution_boundary/authorization_token_issued`; `decision_receipt.public_sanitized.json` → `/authorization_token` | Was release authorization withheld? |
| 6 | Downstream commit not executed | Present | `/execution_boundary/downstream_commit_status`; `/downstream_effect_record/workflow_commit_executed` | Did downstream commit remain unformed? |
| 7 | No protected effect formed | Present | `/execution_boundary/protected_effect_formed`; `/no_bind_receipt/no_bind_status` | Does the artifact prove no protected effect formed? |
| 8 | No-bind receipt | Present | `/no_bind_receipt`; `decision_receipt.public_sanitized.json` → `/no_bind_receipt` | Is the no-bind receipt explicit and hash-bound? |
| 9 | Same-condition replay | Present | `/replay_and_tests/same_condition_replay_status` | Did replay reproduce the result? |
| 10 | Changed-condition replay | Present as controlled fixture | `/replay_and_tests/changed_condition_replay_status` | Is the changed-condition result clearly labeled as controlled fixture? |
| 11 | Route inventory / route registration | Present | `/release_attempt/route_id`; `/route_completeness/route_registered` | Is the route identified and registered? |
| 12 | Route pressure tests | Present | `/replay_and_tests/route_pressure_test_count`; `/replay_and_tests/pressure_test_ids` | Are fail-closed/edge cases represented? |
| 13 | Bypass-prevention evidence | Present for controlled harness | `/replay_and_tests/bypass_prevention_evidence_count`; `/route_completeness/non_bypassable` | Is non-bypassability limited to the controlled topology? |
| 14 | Route completeness labeling | Present and bounded | `/route_completeness/route_completeness_level`; `/route_completeness/production_enforcement_asserted` | Is the route level honest and not overclaimed? |

## Pass/Fail Interpretation

A pass means the controlled seam proof is reviewable. It does **not** mean production L5 non-bypassability is proven.
