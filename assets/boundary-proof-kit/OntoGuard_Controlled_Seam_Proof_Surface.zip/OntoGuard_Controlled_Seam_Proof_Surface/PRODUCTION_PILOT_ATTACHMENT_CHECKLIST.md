# Production Pilot Attachment Checklist

This checklist defines what a bounded corridor pilot must attach before claiming production route completeness or production non-bypassability.

## Production topology and route evidence

- [ ] Production route inventory with route IDs, route owners, protected downstream effects, and consequence class.
- [ ] Real downstream release/commit endpoint identified.
- [ ] OntoGuard deployed inline before the real downstream endpoint.
- [ ] Production policy/config snapshot attached.
- [ ] Production control point documented.
- [ ] System-of-record or business-effect boundary documented.

## Authorization and non-bypassability evidence

- [ ] Valid OntoGuard authorization token required for commit.
- [ ] Missing token rejected.
- [ ] Invalid token rejected.
- [ ] Expired token rejected.
- [ ] Route-mismatched token rejected.
- [ ] Decision-hash-mismatched token rejected.
- [ ] Direct bypass attempt rejected.
- [ ] Bypass-attempt logs attached.
- [ ] Fail-closed behavior shown for timeout, stale policy, or unavailable validator.

## Replay and pressure testing

- [ ] Same-condition replay executed against the attached production route.
- [ ] Changed-condition replay executed against the attached production route.
- [ ] Route pressure tests passed under production-like conditions.
- [ ] Load/concurrency behavior observed or bounded.
- [ ] Adversarial or malformed request tests executed where appropriate.

## Authority and review attachments

- [ ] Policy owner attached.
- [ ] Delegated authority record attached.
- [ ] Semantic constraint authority attached.
- [ ] Reviewer role and qualification attached.
- [ ] Human-review task ownership attached.
- [ ] Reviewer outcome attached for ESCALATE cases before closure is claimed.
- [ ] Material limitations resolved or explicitly waived by authorized reviewer.

## Customer benchmark and evidence context

- [ ] Customer-specific policy baseline or evaluation corpus attached where required.
- [ ] External or customer benchmark criteria documented where required.
- [ ] Citation/clause linkage requirements defined for regulated workflows.
- [ ] Data handling and privacy boundaries documented.

## Allowed claim after all evidence is attached

Only after the above evidence is attached and verified should the claim move from controlled L4 route enforcement toward production route completeness. Until then, the correct claim remains: controlled execution-boundary no-bind proof under a controlled inline harness, not production L5 non-bypassability.
