# Artifact Map — Controlled Seam Proof Surface

Use this map against the public-sanitized Boundary Proof Kit. It points to artifacts and paths only; it does not disclose implementation logic.

| Proof item | Primary artifact | JSON pointer or section | Supporting artifact |
|---|---|---|---|
| Attempted movement | `controlled_runtime_seam_summary.public_sanitized.json` | `/release_attempt/attempted_movement` | `governance.public_sanitized.pdf` → Runtime-seam proof section |
| Requested/refused operation | `controlled_runtime_seam_summary.public_sanitized.json` | `/release_attempt/requested_operation`, `/execution_boundary/refused_operation` | `decision_receipt.public_sanitized.json` → `/no_bind_receipt/refused_operation` |
| Gate invocation | `controlled_runtime_seam_summary.public_sanitized.json` | `/execution_boundary/control_point`, `/execution_boundary/gate_mode`, `/execution_boundary/gate_invoked_before_release` | `governance.public_sanitized.pdf` |
| Failed conditions | `controlled_runtime_seam_summary.public_sanitized.json` | `/execution_boundary/failed_conditions` | `buyer_portable.governance.public_sanitized.json` summary fields |
| Decision result | `decision_receipt.public_sanitized.json` | `/decision` | `buyer_portable.governance.public_sanitized.json` → decision summary |
| No authorization token issued | `decision_receipt.public_sanitized.json` | `/authorization_token/issued`, `/authorization_token/status` | `controlled_runtime_seam_summary.public_sanitized.json` → `/release_attempt/authorization_token_status` |
| Downstream commit not executed | `controlled_runtime_seam_summary.public_sanitized.json` | `/downstream_effect_record/workflow_commit_executed`, `/downstream_effect_record/downstream_commit_status` | `decision_receipt.public_sanitized.json` → `/downstream_effect_record` |
| No protected effect formed | `controlled_runtime_seam_summary.public_sanitized.json` | `/execution_boundary/protected_effect_formed`, `/no_bind_receipt/no_bind_status` | `one_page_refusal_escalation_receipt.public_sanitized.pdf` |
| No-bind receipt | `decision_receipt.public_sanitized.json` | `/no_bind_receipt` | `controlled_runtime_seam_summary.public_sanitized.json` → `/no_bind_receipt` |
| Same-condition replay | `controlled_runtime_seam_summary.public_sanitized.json` | `/replay_and_tests/same_condition_replay_status` | `governance.public_sanitized.pdf` |
| Changed-condition replay | `controlled_runtime_seam_summary.public_sanitized.json` | `/replay_and_tests/changed_condition_replay_status` | `governance.public_sanitized.pdf` |
| Route pressure tests | `controlled_runtime_seam_summary.public_sanitized.json` | `/replay_and_tests/route_pressure_test_count`, `/replay_and_tests/route_pressure_tests_passed`, `/replay_and_tests/pressure_test_ids` | `boundary_proof_kit_manifest.public_sanitized.json` |
| Bypass-prevention evidence | `controlled_runtime_seam_summary.public_sanitized.json` | `/replay_and_tests/bypass_prevention_evidence_count`, `/replay_and_tests/bypass_prevention_passed` | `governance.public_sanitized.pdf` |
| Route completeness label | `controlled_runtime_seam_summary.public_sanitized.json` | `/route_completeness/route_completeness_level`, `/route_completeness/production_enforcement_asserted` | `decision_receipt.public_sanitized.json` → `/route_completeness_level`, `/production_enforcement_asserted` |
| Public limitation | `controlled_runtime_seam_summary.public_sanitized.json` | `/honest_limitations` | `boundary_proof_kit_manifest.public_sanitized.json` → `/not_asserted` |

## Exact public kit filenames referenced

- `controlled_runtime_seam_summary.public_sanitized.json`
- `decision_receipt.public_sanitized.json`
- `buyer_portable.governance.public_sanitized.json`
- `governance.public_sanitized.pdf`
- `one_page_refusal_escalation_receipt.public_sanitized.pdf`
- `boundary_proof_kit_manifest.public_sanitized.json`
