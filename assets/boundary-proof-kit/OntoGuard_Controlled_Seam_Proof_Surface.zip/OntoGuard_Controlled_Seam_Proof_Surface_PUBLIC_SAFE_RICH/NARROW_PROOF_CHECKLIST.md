# Public Technical Proof Checklist

## Current governed event
- [x] ESCALATE decision is explicit.
- [x] Release is withheld.
- [x] Downstream protected commit is not formed.
- [x] Human review is pending.
- [x] Primary causal authority gap is separate from diagnostics.

## Pre-Transition Floor
- [x] Floor precedes authorization.
- [x] STANDING is not authorization.
- [x] NO_STANDING can prevent Decision API invocation.
- [x] Non-formation does not invent BLOCK or ESCALATE.
- [x] Materially changed governing conditions require fresh evaluation.

## Controlled seam
- [x] 22/22 mandatory controlled cases passed.
- [x] Valid authorization permits exactly one controlled commit.
- [x] Non-ALLOW/failure states produce zero protected commit.
- [x] Missing/malformed authorization fails closed.
- [x] Context/binding mismatches fail closed.
- [x] Stale/revoked/expired/reused authorization fails closed.
- [x] Concurrent duplicate handling produces exactly one commit.
- [x] Direct/alternate bypass categories fail closed.
- [x] Same-condition replay passes.
- [x] Changed-condition replay re-enters the governed gate.

## Authority / evidence / causality
- [x] Missing authority is not fabricated.
- [x] Candidate evidence remains distinct from governing and causal evidence.
- [x] Decision-causal evidence remains unestablished for the current event.
- [x] Citation/applicability/authority/causality distinctions remain explicit.

## Longitudinal / diagnostics
- [x] Intent Horizon is pre-decision.
- [x] Semantic Curvature is honestly `INSUFFICIENT_HISTORY`.
- [x] Governance Spectrum is honestly `INSUFFICIENT_HISTORY`.
- [x] Review-gated feedback does not mutate live policy/model state.

## Artifact / claim boundary
- [x] Canonical private strict-six is verified.
- [x] Receipt and manifest bind final handoff.
- [x] Single-event hard failures = 0.
- [x] Latest batch limitation is disclosed.
- [x] Production-wide non-bypassability is not asserted.
