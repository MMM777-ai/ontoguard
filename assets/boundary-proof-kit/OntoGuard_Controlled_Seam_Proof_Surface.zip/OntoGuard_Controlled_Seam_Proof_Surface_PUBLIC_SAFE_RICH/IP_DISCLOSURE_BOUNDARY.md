# IP Disclosure Boundary - Public-Safe Rich Controlled Seam

## Included
- observable decisions and release outcomes;
- formation/non-formation semantics;
- authority/evidence/citation/causality status;
- grouped pressure-test coverage and outcomes;
- replay outcomes;
- trust/uncertainty bands;
- longitudinal-governance status;
- strict-six readiness and acceptance posture.

## Intentionally withheld
- source code, source paths and callable identities;
- private run/route/test/receipt/evidence identifiers;
- private decision/input/movement/standing/handoff hashes;
- exact downstream authorization-binding dimensions;
- exact attack-case-to-binding-axis mapping;
- model, retrieval and internal-representation implementation details;
- exact score values, formulas, weights, coefficients and numeric thresholds;
- role-level arbitration identities and score mechanics;
- raw prompts, model outputs, evidence bodies, traces and private registry content;
- exact private packet byte sizes and fine-grained performance fingerprints;
- secrets, credentials and private signing material.

This boundary is designed to preserve public proof value while materially reducing trade-secret inference risk.
