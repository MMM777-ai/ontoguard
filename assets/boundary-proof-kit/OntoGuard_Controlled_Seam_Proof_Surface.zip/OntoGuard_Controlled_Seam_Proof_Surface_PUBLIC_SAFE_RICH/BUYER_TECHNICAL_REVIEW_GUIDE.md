# Buyer / Technical Reviewer Guide - Public-Safe Rich Controlled Seam

This guide explains what the public evidence demonstrates without exposing OntoGuard's private binding schema, metric formulas, model/retrieval internals, private hashes, or deployment topology.

## 1. Formation before authorization
Review `pre_transition_governing_floor` in `MINIMAL_SANITIZED_JSON_EXCERPT.json`.
Confirm:
- the Floor precedes authorization;
- standing is eligibility, not authorization;
- NO_STANDING can prevent formation;
- non-formation does not fabricate BLOCK/ESCALATE;
- changed material conditions require fresh standing.

## 2. Authoritative decision and release truth
Review `current_event`, `decision_and_authority`, and `semantic_decision_handoff`.
Confirm:
- current decision = ESCALATE;
- release = withheld;
- downstream protected effect = not formed;
- missing institutional authority remains missing;
- the Decision API remains the sole decision/release authority.

## 3. Evidence and legal-semantic separation
Confirm that candidate context is not represented as governing basis, applicability, authority, or causality. Public aggregate bands/statuses are retained, while private evidence identities, retrieval mechanics and candidate-scoring details are withheld.

## 4. Trust and governance diagnostics
The public package keeps the buyer-relevant posture:
- output reliability trust = LOW band;
- decision-basis/presented governance trust = MODERATE band;
- uncertainty = HIGH band;
- multi-role arbitration executed with mixed votes;
- diagnostic vectors are shown as bands.

Exact score values, role-level scores, formulas, weights and signal contracts are intentionally not public.

## 5. Intent and longitudinal governance
Intent Horizon is shown as pre-decision and review-requiring. Semantic Curvature and Governance Spectrum remain `INSUFFICIENT_HISTORY` and non-decisioning. Exact private thresholds and minimum-history fingerprints are withheld.

## 6. Controlled Full Seam
The public surface retains 22/22 pass coverage but groups the private attack/binding taxonomy into eight public categories. This proves breadth without publishing the internal authorization-binding blueprint.

## 7. Artifact and acceptance truth
The canonical private strict-six is verified, receipt/manifest bind the final handoff, and current single-event hard failures are zero. The latest batch limitation is also disclosed rather than hidden.

## 8. What this package does not prove
It does not prove production-wide non-bypassability, customer production topology, customer delegated authority, or a closed human-review outcome.
