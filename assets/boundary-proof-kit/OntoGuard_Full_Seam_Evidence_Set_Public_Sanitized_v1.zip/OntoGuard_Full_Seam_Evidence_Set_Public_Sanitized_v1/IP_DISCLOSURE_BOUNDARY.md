# IP Disclosure Boundary

This public-sanitized evidence set is designed to permit independent inspection of **behavioral proof** without disclosing the implementation mechanics that create that behavior.

## Included

- bounded object and protected consequence class;
- route and operation identifiers used by the controlled proof;
- condition *classes* needed for the bounded standing;
- cryptographic hashes binding movement, frozen decision input, decision, standing condition, grant and protected state;
- expected vs observed outcomes;
- before/after protected-state hashes;
- commit counts and protected-effect booleans;
- same-condition and changed-condition replay outcomes;
- bypass/rejection and non-formation evidence;
- source archive hashes and claim limitations.

## Intentionally withheld

- source code and executable implementation;
- internal Python/module/function names or call graph;
- proprietary policy evaluation logic and rule internals;
- ontology internals, private registries and knowledge-asset contents;
- raw prompts, model outputs, embeddings or latent representations;
- proprietary scoring formulas, weighting logic or unreleased thresholds;
- raw evidence text/citation corpora and private mappings;
- credentials, secrets, infrastructure details and customer topology;
- any information that would materially enable reconstruction of the authorization engine rather than verification of its observed behavior.

## Review principle

The reviewer should be able to test the claim **from fixed conditions, bindings and observed outcomes**. Source implementation is not necessary to establish that a bounded controlled route refused bypass/failure cases, replayed correctly, or formed/no-formed the protected consequence under the documented conditions.
