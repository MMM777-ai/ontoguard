# Full-Seam Review Worksheet

Use `FULL_SEAM_REVIEW_MATRIX.json` as the machine-readable index.

| Object | Fixed condition | Expected output | Observed output | Evidence | Replay | Conclusion |
|---|---|---|---|---|---|---|
| Controlled release-state transition | Exact registered route + current evidence + route authority + policy + semantic identity + canonical ALLOW + one-time bound grant | One protected commit | T-01 committed once | Boundary + binding files | T-21 | Supported |
| Same object under 22 route-pressure conditions | Each test's explicit condition | Explicit commit/refusal expectation | 22/22 matched | Route-pressure JSON/CSV | T-21/T-22 | PASS |
| Direct/alternate bypass attempts | No valid bound gate authorization | Refuse, zero commit | T-19/T-20 refused | Bypass file | N/A | Controlled bypass rejection proven |
| Refusal condition | BLOCK/ESCALATE/invalid or stale grant/bypass | No effect | Zero commit; before=after; effect=false | No-effect record | Multiple cases | Non-formation proven |
| Bound grant/receipt | Movement + frozen input + decision + standing + route + operation + nonce | Commit only on exact match | Valid binding committed; mismatch cases refused | Sanitized receipt + T-11..T-16 | Changed replays use fresh hashes | Binding proven |
| Same condition | Equivalent standing | Same action/release/effect | Replay comparison passed | Replay file | Executed | PASS |
| Changed condition | movement/evidence/authority/policy version changes | Re-evaluate via gate | 4 changed replays executed; stale old grant rejected | Replay + T-17/T-22 | Executed | PASS controlled fixture |

**Overall:** supports `L4_ROUTE_ENFORCED` for `CONTROLLED_SINGLE_ROUTE_ONLY`; does not establish production L5.
