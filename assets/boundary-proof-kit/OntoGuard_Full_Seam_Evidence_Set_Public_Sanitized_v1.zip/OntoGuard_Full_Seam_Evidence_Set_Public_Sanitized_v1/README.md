# OntoGuard Full-Seam Evidence Set — Public Sanitized v1

Generated: 2026-08-24T12:04:15Z

This package answers a third-party Full-Seam engineering review using the requested sequence:

**object → fixed condition → expected output → observed output → evidence → replay → conclusion**

## What this package supports

- Controlled Full Seam: **PASS — 22/22 mandatory tests**
- Controlled route maturity: **L4_ROUTE_ENFORCED**
- Scope: **CONTROLLED_SINGLE_ROUTE_ONLY**
- Production enforcement asserted: **false**
- Production L5 / production-wide non-bypassability: **not asserted**

The protected consequence is a **CONTROLLED_RELEASE_STATE_TRANSITION** into **CONTROLLED_STATE**. The evidence shows one valid exact ALLOW grant committing that protected consequence once, while BLOCK/ESCALATE, invalid/stale/mismatched grants, direct-gate bypass, alternate-route bypass and related failure conditions are refused before the protected effect forms.

## Evidence files

- `BOUNDED_OBJECT_AND_PROTECTED_BOUNDARY.json` — the object, protected consequence and exact bounded control boundary.
- `FIXED_CONDITION_AND_AUTHORIZATION_BINDING.json` — buyer-safe standing-condition classes plus cryptographic binding evidence.
- `CONTROLLED_STANDING_CONDITION_PUBLIC_SANITIZED.json` — direct sanitized projection of the canonical standing-condition object.
- `CONTROLLED_AUTHORIZATION_GRANT_PUBLIC_SANITIZED.json` — direct sanitized projection of the canonical one-time grant and its movement/input/decision bindings.
- `CONTROLLED_PROTECTED_COMMIT_RECORD_PUBLIC_SANITIZED.json` — direct sanitized projection of the canonical protected commit and validation results.
- `ROUTE_PRESSURE_TESTS_PUBLIC_SANITIZED.json/.csv` — all 22 expected/observed test records.
- `BYPASS_AND_REJECTION_EVIDENCE.json` — direct bypass, alternate route, stale/missing/mismatched grant and duplicate-request outcomes.
- `REPLAY_EVIDENCE_PUBLIC_SANITIZED.json` — same-condition replay plus four changed-condition replays and stale-grant-after-change rejection.
- `REFUSAL_NON_FORMATION_NO_EFFECT_RECORD.json` — refusal cases with zero commits, false effect formation and unchanged protected-state hashes.
- `SANITIZED_MOVEMENT_AND_GOVERNING_STATE_RECEIPT.json` — a **derived public projection**, not a new canonical runtime receipt, showing the movement/governing-state/authorization/consequence binding hashes.
- `FULL_SEAM_REVIEW_MATRIX.json` — direct mapping to the requested review sequence.
- `CURRENT_EVENT_NO_BIND_SUPPLEMENT.json` — separate actual-current-event no-bind evidence; this is **not** the L4 fixture.
- `SOURCE_BINDING.json` — source archive and Goal-spec hashes.

## Important replay distinction

The ordinary current event was in `SHADOW_MODE`; its own changed-condition replay remains `NOT_EXECUTED_WITH_REASON`. The **controlled Full-Seam fixture**, separately, executed one same-condition replay and four changed-condition replays. This package does not merge those evidence classes.

## Claim boundary

The evidence supports the stronger standing **only for the bounded controlled route**. It does not claim customer-production topology, production-wide bypass resistance, or L5 route completeness.

See `IP_DISCLOSURE_BOUNDARY.md` for what is intentionally withheld.
